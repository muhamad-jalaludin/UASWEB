# RekamMedis

Native Website with PHP, JS, Bootstrap....
Sistem rekam medis untuk rumah sakit dsb.

Tutorial pake
-

- Buat db bernama <code>rekam_medis</code>
- Import db <code>rekam_medis.sql</code>
- Edit file <code>auth/connect.php</code> sesuaikan username dan password dengan servermu
- Enjoy

Daripada download berulang - ulang
-

Ya sorry, bisanya update kecil-kecilan doang... Biar enak pake <a href="https://github.com/git-for-windows/git/releases/download/v2.26.1.windows.1/Git-2.26.1-64-bit.exe">GitBash For Windows</a> atau kalau di Linux ya langsung aja pake <code>git</code> aja.


Tata cara pake Git
-

- Clone repo <code>git clone https://github.com/ledleledle/RekamMedis.git</code>
- Pantau update dengan <code>git fetch</code>
- Dan dapatkan update dengan <code>git merge</code>

Rancangan Sistem
-

![rancangansistem](https://raw.githubusercontent.com/ledleledle/RekamMedis/master/blueprint/rancangan.png)

For now its done :)